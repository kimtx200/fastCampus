package com.taewonkim.android.myboard;

/**
 * Created by 태원 on 2016-10-11.
 */
public interface onFragmentListener {
    void action(int flag);
}
