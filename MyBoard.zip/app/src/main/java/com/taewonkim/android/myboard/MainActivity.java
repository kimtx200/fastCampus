package com.taewonkim.android.myboard;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements onFragmentListener {

    ViewPager pager;
    PagerAdapter adapter;

    ListFragment listFragment;
    DetailFragment detailFragment;

    ArrayList<Fragment> fragmentArr = new ArrayList<>();

    static final int WRITE = 0;
    static final int EDIT = 1;
    static final int SAVE = 2;
    static final int CANCEL = 3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        pager = (ViewPager) findViewById(R.id.viewPager);
        listFragment = new ListFragment();
        detailFragment = new DetailFragment();

        fragmentArr.add(listFragment);
        fragmentArr.add(detailFragment);

        adapter = new ViewPagerAdapter(getSupportFragmentManager());
        pager.setAdapter(adapter);
    }

    @Override
    public void action(int flag) {
        switch(flag){
            case WRITE:
                write();
                break;

            case EDIT:
                edit();
                break;

            case SAVE:
                save();
                break;

            case CANCEL:
                cancel();
                break;
        }
    }

    private class ViewPagerAdapter extends FragmentStatePagerAdapter {

        public ViewPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            return fragmentArr.get(position);
        }

        @Override
        public int getCount() {
            return 2;
        }
    }

    public void write() {
        Toast.makeText(this, "Go to Write page", Toast.LENGTH_SHORT).show();
    }

    public void edit() {
        Toast.makeText(this, "Go to Edit page", Toast.LENGTH_SHORT).show();
    }

    public void save() {
        Toast.makeText(this, "Save Successfully !!", Toast.LENGTH_SHORT).show();
    }

    public void cancel() {
        Toast.makeText(this, "Edit Canceled", Toast.LENGTH_SHORT).show();
    }

}


