package com.taewonkim.android.myboard;

/**
 * Created by 태원 on 2016-10-11.
 */
public class ListData {

    int no;
    String title;
    String name;
    String contents;
    String nDate;

}
